
/*Populate CustomerBrand table*/
IF OBJECT_ID('dbo.CustomerBrand', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.CustomerBrand)
BEGIN
	INSERT INTO dbo.CustomerBrand (BrandName)
		SELECT CustomerBrandName 
		FROM dbo.DepositTransactionsSource
	UNION
		SELECT CustomerBrand 
		FROM dbo.GamePlayTransactionsSource
	ORDER BY CustomerBrandName ASC
END;

/*Populate Country table*/
IF OBJECT_ID('dbo.Country', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.Country)
BEGIN
	INSERT INTO dbo.Country (CountryName)
		SELECT CustomerCountry 
		FROM dbo.DepositTransactionsSource
	UNION
		SELECT CustomerCountry 
		FROM dbo.GamePlayTransactionsSource
	ORDER BY CustomerCountry ASC
END;

/*Populate CustomerStatus table*/
IF OBJECT_ID('dbo.CustomerStatus', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM CustomerStatus)
BEGIN
	INSERT INTO dbo.CustomerStatus (CustomerStatusId, StatusDescription)
	SELECT  
		CASE CustomerAccountStatus WHEN 'Active' THEN 1 WHEN 'Closed' THEN 0  END ,
		CustomerAccountStatus
	FROM dbo.DepositTransactionsSource
	UNION
	SELECT 
		CASE CustomerStatus WHEN 'Active' THEN 1 WHEN 'Closed' THEN 0  END,
		CustomerStatus
	FROM dbo.GamePlayTransactionsSource
END;

/*Populate Customer table*/
IF OBJECT_ID('dbo.Customer', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM  Customer)
BEGIN
	INSERT INTO dbo.Customer (Email, CustomerBrandId, CountryId, CustomerStatusId)
		SELECT dt.CustomerEmail, cb.CustomerBrandId, c.CountryID,  cs.CustomerStatusId
		FROM dbo.DepositTransactionsSource dt 
		INNER JOIN dbo.CustomerBrand cb ON dt.CustomerBrandName = cb.BrandName  
		INNER JOIN dbo.Country c ON dt.CustomerCountry = c.CountryName
		INNER JOIN dbo.CustomerStatus cs ON dt.CustomerAccountStatus = cs.StatusDescription
	UNION
		SELECT gt.CustomerEmail, cb.CustomerBrandId, c.CountryID,  cs.CustomerStatusId 
		FROM dbo.GamePlayTransactionsSource gt
		INNER JOIN dbo.CustomerBrand cb ON gt.CustomerBrand = cb.BrandName  
		INNER JOIN dbo.Country c ON gt.CustomerCountry = c.CountryName
		INNER JOIN dbo.CustomerStatus cs ON gt.CustomerStatus = cs.StatusDescription
	ORDER BY CustomerEmail ASC
END;

/*Populate PaymentMethod table*/
IF OBJECT_ID('dbo.PaymentMethod', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM PaymentMethod)
BEGIN
	INSERT INTO dbo.PaymentMethod (MethodName, MethodType)
		SELECT  PaymentMethodName, PaymentMethodType
		FROM dbo.DepositTransactionsSource
		GROUP BY PaymentMethodName, PaymentMethodType

END;

/*Populate PaymentStatus table*/
IF OBJECT_ID('dbo.PaymentStatus', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM PaymentStatus)
BEGIN
	INSERT INTO dbo.PaymentStatus (StatusName, StatusDescription)
		SELECT  PaymentStatusName, PaymentStatusDescription
		FROM dbo.DepositTransactionsSource
		GROUP BY PaymentStatusName, PaymentStatusDescription
		ORDER BY PaymentStatusName
END;

/*Populate GameProvider table*/
IF OBJECT_ID('dbo.GameProvider', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.GameProvider)
BEGIN
	INSERT INTO dbo.GameProvider (ProviderName)
		SELECT  ProviderName
		FROM dbo.GamePlayTransactionsSource
		GROUP BY ProviderName
		ORDER BY ProviderName
END;

/*Populate Product table*/
IF OBJECT_ID('dbo.Product', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.Product)
BEGIN
	INSERT INTO dbo.Product (ProductName)
		SELECT  ProviderProductName
		FROM dbo.GamePlayTransactionsSource
		GROUP BY ProviderProductName
		ORDER BY ProviderProductName
END;

/*Populate Provider_Product table*/
IF OBJECT_ID('dbo.Provider_Product', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM dbo.Provider_Product)
BEGIN
	INSERT INTO dbo.Provider_Product (ProviderId, ProductId)
		SELECT  gp.GameProviderId, p.ProductId
		FROM dbo.GamePlayTransactionsSource gt 
			INNER JOIN dbo.GameProvider gp ON gt.ProviderName =gp.ProviderName
			INNER JOIN dbo.Product p ON ISNULL(gt.ProviderProductName,'') = ISNULL(p.ProductName,'')
		GROUP BY  gp.GameProviderId, p.ProductId
		ORDER BY  gp.GameProviderId, p.ProductId
END;

/*Populate Device table*/
IF OBJECT_ID('dbo.Device', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM Device)
BEGIN
	INSERT INTO dbo.Device (DeviceName)
		SELECT  DeviceName
		FROM dbo.GamePlayTransactionsSource
		GROUP BY DeviceName
		ORDER BY DeviceName
END;

/*Populate DepositTransactions table*/
IF OBJECT_ID('dbo.DepositTransactions', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM DepositTransactions)
BEGIN
	INSERT INTO dbo.DepositTransactions (CalendarDate, CustomerId, PaymentMethodId, PaymentStatusId, amount_eur)
		SELECT  dt.CalendarDate, c.CustomerId, pm.PaymentMethodId, ps.PaymentStatusId, amount_eur
		FROM dbo.DepositTransactionsSource dt   
			INNER JOIN dbo.Customer c ON dt.CustomerEmail = c.Email 
			INNER JOIN dbo.PaymentMethod pm ON dt.PaymentMethodName = pm.MethodName 
				AND dt.PaymentMethodType = pm.MethodType
			INNER JOIN dbo.PaymentStatus ps ON dt.PaymentStatusName = ps.StatusName
				AND dt.PaymentStatusDescription = ps.StatusDescription
END;

/*Populate GamePlayTransactions table*/
IF OBJECT_ID('dbo.GamePlayTransactions', 'U') IS NOT NULL AND NOT EXISTS(SELECT TOP 1 1 FROM GamePlayTransactions)
BEGIN
	INSERT INTO dbo.GamePlayTransactions (CalendarDate, CustomerId, Provider_ProductId, DeviceId,
												rounds, turnover_EUR, gameWin_eur, bonus_cost, totalAccountingRevenue_EUR)
		SELECT  gt.CalendarDate, c.CustomerId, pp.Provider_ProductId, d.DeviceId,
				gt.rounds, gt.turnover_EUR, gt.gameWin_eur, gt.bonus_cost, gt.totalAccountingRevenue_EUR
		FROM dbo.GamePlayTransactionsSource gt   
			INNER JOIN dbo.Customer c ON gt.CustomerEmail = c.Email
			INNER JOIN dbo.GameProvider gp ON gt.ProviderName = gp.ProviderName
			INNER JOIN dbo.Product p ON ISNULL(gt.ProviderProductName,'') = ISNULL(p.ProductName,'')
			INNER JOIN dbo.Provider_Product pp ON gp.GameProviderId = pp.ProviderId 
				AND p.ProductId = pp.ProductId
			INNER JOIN dbo.Device d ON gt.DeviceName = d.DeviceName
END;
			