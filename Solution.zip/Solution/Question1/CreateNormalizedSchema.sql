/*
sp_configure 'show advanced options', 1;
RECONFIGURE;
GO
sp_configure 'Ad Hoc Distributed Queries', 1;
RECONFIGURE; 
GO
USE [BetssonMG]
GO
SELECT * INTO DepositTransactionsSource
FROM OPENROWSET ('Microsoft.ACE.OLEDB.12.0','Excel 12.0; Database=C:\Users\algal\Desktop\maria\Question1-Material.xlsx', 'select * from [DBtest.dbo.DepositTransactions$]');
GO
SELECT * INTO GamePlayTransactionsSource
FROM OPENROWSET ('Microsoft.ACE.OLEDB.12.0','Excel 12.0; Database=C:\Users\algal\Desktop\maria\Question1-Material.xlsx', 'select * from [DBtest.dbo.GamePlayTransactions$]');
GO
*/

-- UPDATE [DepositTransactionsSource]
-- SET CustomerEmail= REPLACE (CustomerEmail, '.om', '.com')



/*Create CustomerBrand table*/
IF OBJECT_ID('dbo.CustomerBrand', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.CustomerBrand
		(
		CustomerBrandId int IDENTITY (1,1) NOT NULL,
		BrandName varchar(50) NOT NULL,
	CONSTRAINT [PK_CustomerBrand] PRIMARY KEY CLUSTERED 
		(
			CustomerBrandId ASC
		))
END;

/*Create Country table*/
IF OBJECT_ID('dbo.Country', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.Country
	(
		CountryID int IDENTITY (1,1) NOT NULL,
		CountryName varchar(50) NOT NULL,
	CONSTRAINT [PK_Country] PRIMARY KEY CLUSTERED 
	(
		CountryID ASC
	))
END;


/*Create CustomerStatus table*/
IF OBJECT_ID('dbo.CustomerStatus', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.CustomerStatus 
		(CustomerStatusId int NOT NULL,
		StatusDescription varchar (10)	
	CONSTRAINT [PK_CustomerStatus] PRIMARY KEY CLUSTERED 
		(
			CustomerStatusID ASC
		))
END;

/*Create Customer table*/
IF OBJECT_ID('dbo.Customer', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.Customer
		(
		CustomerId int IDENTITY (1,1) NOT NULL,
		Email varchar(50) NOT NULL,
		CustomerBrandId int NOT NULL,
		CountryID int NOT NULL,
		CustomerStatusId int NOT NULL,
	CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
		(
			CustomerId ASC
		))
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_Customer_CustomerBrand]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[Customer] ADD CONSTRAINT [FK_Customer_CustomerBrand] 
	FOREIGN KEY([CustomerBrandId]) REFERENCES [dbo].[CustomerBrand] ([CustomerBrandId])
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_Customer_Country]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[Customer] ADD CONSTRAINT [FK_Customer_Country] 
	FOREIGN KEY([CountryId]) REFERENCES [dbo].[Country] ([CountryId])
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_Customer_CustomerStatus]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[Customer] ADD CONSTRAINT [FK_Customer_CustomerStatus] 
	FOREIGN KEY([CustomerStatusId]) REFERENCES [dbo].[CustomerStatus] ([CustomerStatusId])
END;

/*Create PaymentMethod table*/
IF OBJECT_ID('dbo.PaymentMethod', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.PaymentMethod 
		(
		PaymentMethodID int IDENTITY (1, 1) NOT NULL,
		MethodName varchar (10),
		MethodType varchar (10)

	CONSTRAINT [PK_PaymentMethod] PRIMARY KEY CLUSTERED 
	(
		PaymentMethodID ASC
	))
END;

/*Create PaymentStatus table*/
IF OBJECT_ID('dbo.PaymentStatus', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.PaymentStatus
		(
		PaymentStatusId int IDENTITY (1, 1) NOT NULL,
		StatusName varchar (10),
		StatusDescription varchar (50)

	CONSTRAINT [PK_PaymentStatus] PRIMARY KEY CLUSTERED 
	(
		PaymentStatusId ASC
	))
END;

/*Create GameProvider table*/
IF OBJECT_ID('dbo.GameProvider', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.GameProvider
		(
		GameProviderId int IDENTITY (1, 1) NOT NULL,
		ProviderName varchar (30),
		
	CONSTRAINT [PK_GameProvider] PRIMARY KEY CLUSTERED 
	(
		GameProviderId ASC
	))
END;

/*Create Product table*/
IF OBJECT_ID('dbo.Product', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.Product
		(
		ProductId int IDENTITY (1, 1) NOT NULL,
		ProductName varchar (30),
		
	CONSTRAINT [PK_Product] PRIMARY KEY CLUSTERED 
	(
		ProductId ASC
	))
END;

/*Create Provider_Product table*/
IF OBJECT_ID('dbo.Provider_Product', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.Provider_Product
		(
		Provider_ProductId int IDENTITY (1, 1) NOT NULL,
		ProviderId int NOT NULL,
		ProductId int,
		
	CONSTRAINT [PK_Provider_Product] PRIMARY KEY CLUSTERED 
	(
		Provider_ProductId ASC
	))
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_Provider_Product_GameProvider]')
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[Provider_Product] ADD CONSTRAINT [FK_Provider_Product_GameProvider] 
	FOREIGN KEY([ProviderId]) REFERENCES [dbo].[GameProvider] ([GameProviderId])
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_Provider_Product_Product]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[Provider_Product] ADD CONSTRAINT [FK_Provider_Product_Product] 
	FOREIGN KEY([ProductId]) REFERENCES [dbo].[Product] ([ProductId])
END;

/*Create Device table*/
IF OBJECT_ID('dbo.Device', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.Device
		(
		DeviceId int IDENTITY (1, 1) NOT NULL,
		DeviceName varchar (10),
		
	CONSTRAINT [PK_Device] PRIMARY KEY CLUSTERED 
	(
		DeviceId ASC
	))
END;

/*Create DepositTransactions table*/
IF OBJECT_ID('dbo.DepositTransactions', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.DepositTransactions
		(
		CalendarDate int,
		CustomerId int,
		PaymentMethodId int,
		PaymentStatusId int,
		amount_eur decimal (14,10)
		)
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_DepositTransactions_Customer]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[DepositTransactions] ADD CONSTRAINT [FK_DepositTransactions_Customer]
	FOREIGN KEY([CustomerId]) REFERENCES [dbo].[Customer] ([CustomerId])
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_DepositTransactions_PaymentMethod]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[DepositTransactions] ADD CONSTRAINT [FK_DepositTransactions_PaymentMethod]
	FOREIGN KEY([PaymentMethodId]) REFERENCES [dbo].[PaymentMethod] ([PaymentMethodId])
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_DepositTransactions_PaymentStatus]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[DepositTransactions] ADD CONSTRAINT [FK_DepositTransactions_PaymentStatus]
	FOREIGN KEY([PaymentStatusId]) REFERENCES [dbo].[PaymentStatus] ([PaymentStatusId])
END;

/*Create GamePlayTransactions table*/
IF OBJECT_ID('dbo.GamePlayTransactions', 'U') IS NULL
BEGIN
	CREATE TABLE dbo.GamePlayTransactions
		(
		CalendarDate int,
		CustomerId int,
		Provider_ProductId int,
		DeviceId int,
		rounds int,
		turnover_EUR decimal(14,10),
		gameWin_eur decimal(14,10),
		bonus_cost decimal(14,10),
		totalAccountingRevenue_EUR decimal(14,10)
		)
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_GamePlayTransactions_Customer]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[GamePlayTransactions] ADD CONSTRAINT [FK_GamePlayTransactions_Customer]
	FOREIGN KEY([CustomerId]) REFERENCES [dbo].[Customer] ([CustomerId])
END;

IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_GamePlayTransactions_Provider_Product]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[GamePlayTransactions] ADD CONSTRAINT [FK_GamePlayTransactions_Provider_Product]
	FOREIGN KEY([Provider_ProductId]) REFERENCES [dbo].[Provider_Product] ([Provider_ProductId])
END;
IF NOT EXISTS (SELECT * FROM sys.objects o WHERE o.object_id = object_id(N'[dbo].[FK_GamePlayTransactions_Device]') 
	AND OBJECTPROPERTY(o.object_id, N'IsForeignKey') = 1)
BEGIN
    ALTER TABLE [dbo].[GamePlayTransactions] ADD CONSTRAINT [FK_GamePlayTransactions_Device]
	FOREIGN KEY([DeviceId]) REFERENCES [dbo].[Device] ([DeviceId])
END;
	