/*
1b
Which are the 10 largest completed deposit transactions? 
Extract the amount, customer email, customer brand name and calendar date.
*/

SELECT  TOP 10 c.Email, cb.BrandName, dt.CalendarDate, dt.amount_eur
FROM dbo.DepositTransactions dt
	INNER JOIN dbo.PaymentStatus ps ON dt.PaymentStatusId= ps.PaymentStatusId 
	INNER JOIN dbo.Customer c ON dt.CustomerId = c.CustomerId 
	INNER JOIN dbo.CustomerBrand cb ON c.CustomerBrandId = cb.CustomerBrandId
WHERE ps.StatusName = 'Completed'
ORDER BY dt.amount_eur DESC

/*
1c
What is the total number and amount of failed deposit transactions per brand? 
Extract total number, amount, customer brand name, paymentstatus.
*/
SELECT  COUNT(*) as TotalNumber, SUM(dt.amount_eur) as Amount, MIN(cb.BrandName) as BrandName, ps.StatusName
FROM dbo.DepositTransactions dt
	INNER JOIN dbo.PaymentStatus ps ON dt.PaymentStatusId= ps.PaymentStatusId 
	INNER JOIN dbo.Customer c ON dt.CustomerId = c.CustomerId 
	INNER JOIN dbo.CustomerBrand cb ON c.CustomerBrandId = cb.CustomerBrandId
WHERE ps.StatusName = 'Failed'
GROUP BY cb.CustomerBrandId, ps.StatusName

/*
1d
How much daily turnover and accounting revenue did each brand generates per product 
in the first 6 days of the year? Extract turnover, accountingrevenue, brand.
*/

SELECT MIN(cb.BrandName) as BrandName, MIN(p.ProductName) as ProductName, gt.CalendarDate,
		SUM(gt.turnover_EUR) as turnover_EUR, SUM(gt.totalAccountingRevenue_EUR) as totalAccountingRevenue_EUR 
FROM (
		SELECT CalendarDate, CustomerId, Provider_ProductId, turnover_EUR, totalAccountingRevenue_EUR 
		FROM dbo.GamePlayTransactions gt WHERE CalendarDate BETWEEN '20210101' AND '20210106'
		) gt
  INNER JOIN dbo.Customer c ON gt.CustomerId = c.CustomerId 
  INNER JOIN dbo.CustomerBrand cb ON c.CustomerBrandId = cb.CustomerBrandId
  INNER JOIN Provider_Product pp ON gt.Provider_ProductId = pp.Provider_ProductId
  INNER JOIN Product p ON pp.ProductId = p.ProductId
GROUP BY c.CustomerBrandId, pp.ProductId,  gt.CalendarDate
ORDER BY BrandName, ProductName, CalendarDate

/*
1e
What is the average gamewin per product? Extract the average gamewin and product.
*/

SELECT MIN(p.ProductName) as ProductName, 
	   AVG(gt.gameWin_eur) as gameWin_eur
FROM dbo.GamePlayTransactions gt
  INNER JOIN Provider_Product pp ON gt.Provider_ProductId = pp.Provider_ProductId
  INNER JOIN Product p ON pp.ProductId = p.ProductId
GROUP BY p.ProductId

/*
1f
Which customers had a lifetime total turnover of 500 EUR or more and what was this total turnover amount? 
Extract turnover, customeremail, customer
*/

SELECT SUM(gt.turnover_EUR) as turnover_EUR, MIN(c.Email) as CustomerEmail, C.CustomerId
FROM dbo.GamePlayTransactions gt
	INNER JOIN dbo.Customer c ON gt.CustomerId = c.CustomerId 
GROUP BY c.CustomerId
HAVING SUM(gt.turnover_EUR) >= 500
