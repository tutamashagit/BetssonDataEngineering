
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Dim')
BEGIN
EXEC('CREATE SCHEMA Dim Authorization dbo')
END;
IF OBJECT_ID('Dim.Customer', 'U') IS NULL
BEGIN 
	CREATE TABLE Dim.Customer
		(
		CustomerKey int NOT NULL,
		Title nvarchar (8) NULL, 
		FirstName nvarchar (50) NULL,
		MiddleName nvarchar (50) NULL,
		LastName nvarchar (50) NULL,
		PhoneNumber nvarchar (25) NULL,
		EmailAddress nvarchar (50) NULL, 
		CONSTRAINT [PK_Customer] PRIMARY KEY CLUSTERED 
		(
			CustomerKey 
		)
	)
END;

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Fact')
BEGIN
EXEC('CREATE SCHEMA Fact Authorization dbo')
END;
IF OBJECT_ID('Fact.Sales', 'U') IS NULL
BEGIN
	CREATE TABLE Fact.Sales
		(
		ProductKey int NOT NULL,
		CustomerKey int NOT NULL,
		SalesOrderID int NOT NULL, 
		SalesOrderDetailID int NOT NULL,
		StatusKey tinyint NOT NULL,
		OrderQuantity smallint NULL,
		UnitPrice money NULL,
		UnitPriceDiscount money NULL,
		LineTotal money NULL
	)
 ALTER TABLE [Fact].[Sales] ADD CONSTRAINT [FK_Fact.Sales_Dim.Customer] 
	FOREIGN KEY([CustomerKey]) REFERENCES [Dim].[Customer] ([CustomerKey])
END;

		
/*

-- the following script is for demo purposes 
-- it is used by pyhon package to load data to the data warehouse schema

INSERT INTO Dim.Customer(CustomerKey,Title,FirstName,MiddleName,LastName,PhoneNumber,EmailAddress) 
SELECT CustomerID, Title, FirstName, MiddleName, LastName, PhoneNumber, EmailAddress 
FROM Sales.Customer c
  LEFT JOIN  [Person].[Person] p ON PersonId = p.BusinessEntityID
  LEFT JOIN [Person].[EmailAddress] e  ON e.BusinessEntityID = p.BusinessEntityID
  LEFT JOIN [Person].[PersonPhone] pp ON pp.BusinessEntityID = p.BusinessEntityID


INSERT INTO Fact.Sales (ProductKey, CustomerKey, SalesOrderID, SalesOrderDetailID, StatusKey, OrderQuantity, UnitPrice, UnitPriceDiscount, LineTotal) 
SELECT 
		sod.ProductID,
		soh.CustomerID,
		sod.SalesOrderID, 
		sod.SalesOrderDetailID,
		soh.[Status],
		sod.OrderQty,
		sod.UnitPrice,
		sod.UnitPriceDiscount,
		sod.LineTotal
FROM [Sales].[SalesOrderHeader] soh 
  INNER JOIN [Sales].[SalesOrderDetail] sod
	ON soh.SalesOrderId = sod.SalesOrderId

*/