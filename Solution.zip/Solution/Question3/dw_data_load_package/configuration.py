
# Configuration Parameters

connection_string = ("Driver={SQL Server Native Client 11.0};"
            "Server=localhost;"
            "Database=AdventureWorks;"
            "Trusted_Connection=yes;")