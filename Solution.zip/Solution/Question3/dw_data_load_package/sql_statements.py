
# SQL statements

dim_customer_populate = 'INSERT INTO Dim.Customer(CustomerKey,Title,FirstName,MiddleName,LastName,PhoneNumber,EmailAddress)  ' \
                        'SELECT CustomerID, Title, FirstName, MiddleName, LastName, PhoneNumber, EmailAddress ' \
                        'FROM Sales.Customer c ' \
                        '  LEFT JOIN  [Person].[Person] p ON PersonId = p.BusinessEntityID ' \
                        '  LEFT JOIN [Person].[EmailAddress] e  ON e.BusinessEntityID = p.BusinessEntityID ' \
                        '  LEFT JOIN [Person].[PersonPhone] pp ON pp.BusinessEntityID = p.BusinessEntityID'

fact_sales_populate = 'INSERT INTO Fact.Sales (ProductKey, CustomerKey, SalesOrderID, SalesOrderDetailID, StatusKey, OrderQuantity, UnitPrice, UnitPriceDiscount, LineTotal) ' \
                      'SELECT  sod.ProductID,soh.CustomerID,sod.SalesOrderID,sod.SalesOrderDetailID,soh.[Status],sod.OrderQty,sod.UnitPrice,sod.UnitPriceDiscount,sod.LineTotal ' \
                      'FROM [Sales].[SalesOrderHeader] soh ' \
                      '  INNER JOIN [Sales].[SalesOrderDetail] sod ' \
                      '	 ON soh.SalesOrderId = sod.SalesOrderId'
