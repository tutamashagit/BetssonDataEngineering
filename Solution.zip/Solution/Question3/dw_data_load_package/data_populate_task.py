import configuration
import sql_statements
from db_manager import DBManager


### This task loads data to the warehouse

def execute_task():
    print("\nData Load started ..\n")
    try:
        db_manager = DBManager(configuration.connection_string)

        effected_rows = db_manager.execute(sql_statements.dim_customer_populate)
        print('Customer dimension table populated with ' + str(effected_rows) + ' records')

        effected_rows = db_manager.execute(sql_statements.fact_sales_populate)
        print('Sales fact table populated with ' + str(effected_rows) + ' records')

        print("\nData Load completed successfully !!")

    except BaseException as ex:
        print("Load Failed: " + str(ex))

if __name__ == '__main__':
    execute_task()
