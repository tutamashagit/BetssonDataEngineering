import pyodbc

# DBManager is a class to execute db commands

class DBManager:
    def __init__(self, conn_string):
        self.connection_string = conn_string

    def execute(self, sql_statement):
        try:
            conn = pyodbc.connect(self.connection_string)
            command = conn.cursor()
            command.execute(sql_statement)
            count = command.rowcount
            conn.commit()
        except Exception as ex:
            self.__log_error(ex)
            raise Exception("SQL Execute failed - " + sql_statement)
        finally:
            conn.close()

        return count

    def select(self, sql_statement):
        try:
            conn = pyodbc.connect(self.connection_string)
            cursor = conn.cursor()
            cursor.execute(sql_statement)
            records = cursor.fetchall()
        except Exception as ex:
            self.__log_error(ex)
            raise Exception("SQL Select failed - " + sql_statement)
        finally:
            conn.close()

        return records

    def __log_error(self,ex):
        print('>> error occurred: ' + str(ex))
