﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace Betsson.DataLoad
{
    public class SalesLoadTask
    {
        public void LoadData()
        {
            Console.WriteLine("  >> Data load started");

            var connectionString = ConfigurationManager.AppSettings["connectionString"];
            var sourceLocation = ConfigurationManager.AppSettings["sourceLocation"];
            var processedLocation = ConfigurationManager.AppSettings["processedLocation"];
            var errorLocation = ConfigurationManager.AppSettings["errorLocation"];

            Console.WriteLine("  >> Getting text from " + sourceLocation);

            var files = Directory.GetFiles(sourceLocation);
            foreach (var file in files)
            {
                Console.WriteLine("  >> Processing file " + file);

                try
                {
                    var textLines = File.ReadAllLines(file);
                    var data = textLines.Skip(1).Select(line => line.Split(',')).ToArray();
                    if (data.Length == 0)
                    {
                        MoveFile(file, errorLocation);
                        continue;
                    }

                    var dataTable = BuildDataTable(data);
                    LoadDataTable(dataTable, connectionString);
                    MoveFile(file, processedLocation);
                }
                catch (Exception ex)
                {
                    MoveFile(file, errorLocation);
                }
            }
            Console.WriteLine("  >> Data load completed");

        }

        private DataTable BuildDataTable(string[][] data)
        {
            var table = new DataTable();
            table.Columns.Add("Region", typeof(string));
            table.Columns.Add("Country", typeof(string));
            table.Columns.Add("Item Type", typeof(string));
            table.Columns.Add("Sales Channel", typeof(string));
            table.Columns.Add("Order Priority", typeof(char));
            table.Columns.Add("Order Date", typeof(DateTime));
            table.Columns.Add("Order ID", typeof(int));
            table.Columns.Add("Ship Date", typeof(DateTime));
            table.Columns.Add("Units Sold", typeof(int));
            table.Columns.Add("Unit Price", typeof(decimal));
            table.Columns.Add("Unit Cost", typeof(decimal));
            table.Columns.Add("Total Revenue", typeof(decimal));
            table.Columns.Add("Total Cost", typeof(decimal));
            table.Columns.Add("Total Profit", typeof(decimal));

            foreach (var row in data)
            { 
                table.Rows.Add(row);
            }

            return table;
        }
 
        private void LoadDataTable(DataTable table, string connString)
        {
            string tableName = "[dbo].[Sales]";

            var connection = new SqlConnection(connString);
            var bulkcopy = new SqlBulkCopy(connection);
            bulkcopy.DestinationTableName = tableName;

            try
            {
                connection.Open();
                bulkcopy.WriteToServer(table);
            }
            catch (Exception ex)
            { 
                Console.WriteLine("  >> Error Occured " + ex.Message);
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        private void MoveFile(string sourceFile, string destinationPath)
        {
            string fileName = Path.GetFileName(sourceFile);
            string destinationFolder = Path.GetFileName(destinationPath);
            string destinationFile = Path.Combine(destinationPath, fileName);
            File.Move(sourceFile, destinationFile,  true);
            Console.WriteLine("  >> Source file " + fileName + " is moved to " + destinationFolder);
        }
    }
}