﻿using System;

namespace Betsson.DataLoad
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var loadTask = new SalesLoadTask();
            loadTask.LoadData();
        }
    }
}
