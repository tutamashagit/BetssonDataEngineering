
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Order]') AND type in (N'U'))
	DROP TABLE [dbo].[Order]
GO

CREATE TABLE [dbo].[Order]
(
	[Region] [varchar](50) NOT NULL,
	[Country] [varchar](35) NOT NULL,
	[Item Type] [varchar](25) NOT NULL,
	[Sales Channel] [varchar](15) NOT NULL,
	[Order Priority] [char](1) NOT NULL,
	[Order Date] [date] NOT NULL,
	[Order ID] [int] NOT NULL,
	[Ship Date] [date] NOT NULL,
	[Units Sold] [int] NOT NULL,
	[Unit Price] [decimal](9, 2) NOT NULL,
	[Unit Cost] [decimal](9, 2) NOT NULL,
	[Total Revenue] [decimal](9, 2) NOT NULL,
	[Total Cost] [decimal](9, 2) NOT NULL,
	[Total Profit] [decimal](9, 2) NOT NULL
) ON [PRIMARY]
GO
